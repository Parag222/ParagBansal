const quoteapp=JSON.parse(localStorage.getItem('quoteapp')) || [];

document.getElementById('newquote').addEventListener('submit',function (event){
        event.preventDefault();
        const author = document.getElementById('author').value;
        const quote = document.getElementById('quote').value;

        const quotedata = {
            author : author,
            quote : quote
        };
        quoteapp.push(quotedata);
        console.log(quoteapp);

        localStorage.setItem('quoteapp',JSON.stringify(quoteapp));
        // const encodedData = encodeURIComponent(JSON.stringify(quoteapp));
        window.location.href = `index.html`;

});

