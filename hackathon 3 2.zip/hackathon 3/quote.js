window.onload = function(){
    const display = document.getElementById('quote_detail');
    const currentURL = new URL(window.location.href);
    const searchParams = currentURL.searchParams;
    const index = parseInt(searchParams.get('data'));
    const quotedata = JSON.parse(localStorage.getItem('quoteapp')) || [];

    display.innerHTML = `<h1 class="display-3">${quotedata[index].author}</h1>
                         <p>${quotedata[index].quote}</p>
    `

}