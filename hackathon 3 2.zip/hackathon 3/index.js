window.onload =function(){

    const display = document.getElementById('display-row');
    const quotedata = JSON.parse(localStorage.getItem('quoteapp')) || [];

    
    quotedata.forEach((item,index)=>{
        const quote_index = index;
        const encodedData = encodeURIComponent(JSON.stringify(quote_index));
        const small_content = (item.quote).slice(0,120);
        display.innerHTML += `<div class ='card'>
                                <div class="card-header">
                                Quote  ${index+1}
                            </div>
                            <div class="card-body">
                                <blockquote class="blockquote mb-0">
                                    <p>${small_content}</p>
                                    <footer class="blockquote-footer">${item.author}</footer>
                                    <div class="card-btn">
                                        <a href='quote.html?data=${encodedData}'><div class="btn btn-primary">Get Quote</div></a>
                                    </div>
                                </blockquote>
                            </div>
                            </div>`
});
    };
